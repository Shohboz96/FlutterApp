class Question{
  String questionText;
  bool isCorrect;

  Question.name(this.questionText, this.isCorrect);
}