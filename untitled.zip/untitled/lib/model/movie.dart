class Movie{
  String title;
  String subTitle;
  List<String> images;

  Movie(this.title, this.subTitle, this.images);
}